
## @file
# implementation of DoxyGen::PerlFilter.
#


## @class
# Filter from perl syntax API docs to Doxygen-compatible syntax.
# This class is meant to be used as a filter for the
# <a href="http://www.doxygen.org/">Doxygen</a> documentation tool.
package DoxyGen::PerlFilter;

use warnings;
use strict;
use base qw(DoxyGen::Filter);
my $id = __PACKAGE__;

## @method void filter($infh)
# Do the filtering.
# @param infh input filehandle, normally STDIN
sub filter {
    my($self, $infile) = @_;
    open(my $infh, $infile);
    my $current_class = "";
    my $file = [];
    while( <$infh> ) {
        push( @$file, $_ );
    }
    $self->file_contents( $file );
    my $objcontext = 
        grep( /^\s*use\s+base\s/, @$file )
        || grep( /\@ISA/, @$file )
        || grep( /^\s*bless/, @$file )
        || grep( /^\s*sub\s+new\s/, @$file )
        || grep( /\$self/, @$file );

    push( @$file, "" );  # in order to have a delimiting empty line at EOF
    $self->emit_synopsis();
    $self->emit_desc();
    for( my $line=0; $line <= $#$file; ) {
        $_ = $file->[$line++];
	#print "$_\n";
	if (/^use\s+([\w:]+)/)
	{
	    my $inc = $1;
	    $inc =~ s/::/\//g;
	    $self->print("#include \"$inc.pm\"\n");
	}
	elsif (/^package\s+([\w:]+)/)
	{
	    if ($current_class) {
		$self->flush;
		$self->print("};\n");
	    }
	    next unless( $objcontext );
	    $current_class = $1;
	    $self->emit_class( $current_class, $line);
	}
	elsif (/^=head\d/) {
            my @more;
            while ($_ = $file->[$line++]) {
                if (/^=cut/s) {
		    last;
                } else {
		    #print "DOC ---- $_";
                    push @more, $_;
                }
            }
	    
	    $_ = $file->[$line++];
	    while ($_ =~ /^$/)
	    {
		$_ = $file->[$line++];
	    }
	    
	    if (/^\s*sub\s+([\w:]+)/) {
		my( $proto, $name, @args ) = $self->analyze_sub($line-1);
		if( $current_class && @args && ($args[0] eq "\$self") ) {
		    $self->push($self->protection($proto).' Object Methods');
		    $proto =~ s/\$self,*\s*//;
		} elsif( $current_class 
		    && ((@args && ($args[0] eq "\$class")) || ($name eq "new")) ) {
		    $self->push($self->protection($proto).' Class Methods');
		} else {
		    $self->push($self->protection($proto).' Functions');
		}
		$proto = $self->munge_parameters($proto);
		$self->start("\@fn $proto \n<pre>")->more(@more)->end("</pre>\n");
		$self->print($proto, ";\n");
		$self->pop;
	    }   
	    redo if defined $_;
	} 
    }
    $self->flush();
    if ($current_class) {
        $self->print("};\n");
    }
}

sub emit_synopsis
{
    my ($self) = @_;
    my $line = 0;
    my $file = $self->file_contents();
    while ($_ = $file->[$line++] )
    {
	if (/^=head1\s+SYNOPSIS/i)
	{
	    my @more;
	    while ($_ = $file->[$line++]) {
                if (/^=cut/s) {
		    last;
                } else {
                    push @more, $_;
                }
            }
	    $self->start("\@section Synopsis\n<pre>")->more(@more)->end("</pre>\n");
	}
    }
}

sub emit_desc
{
    my ($self) = @_;
    my $line = 0;
    my $file = $self->file_contents();
    while ($_ = $file->[$line++] )
    {
	if (/^=head1\s+DESCRIPTION/i)
	{
	    my @more;
	    while ($_ = $file->[$line++]) {
                if (/^=cut/s) {
		    last;
                } else {
		    #print "DOC ---- $_";
                    push @more, $_;
                }
            }
	    $self->start("\@section Description\n<pre>")->more(@more)->end("</pre>\n");
	}
    }
}

## @method @ analyze_sub( int line )
# analyzes a subroutine declaration starting at the given line. Tries
# to determine whicht arguments it takes.
#
# @param line The line number at which the sub starts
# @return A function prototype, the name of the function and a
#   list of arguments it takes
sub analyze_sub {
    my( $self, $line ) = @_;

    my $file = $self->file_contents();
    $file->[$line] =~ /sub\s+(.*)\{/;
    my $name = $1;
    my $proto;
    my @args;
    if( $name =~ /^(.*)\s*\((.*)\)/ ) {
        $name = $1;
	$proto = $2;
    }
    else {
        my $forward = 5;
        for( my $i=0; $forward && ($i+$line <= $#$file) && ! $proto; $i++ ) {
	    $_ = $file->[$i+$line];
	    if( /^\s*my\s*\((.*)\)\s*=\s*\@_/ ) {
	        $proto = $1;
	    }
	    elsif( /^\s*(local|my)\s*([^\s]*)\s*=\s*shift\s*;/ ) {
	        push( @args, $2 );
	    }
	    elsif( /^\s*(local|my)\s*([^\s]*)\s*=\s*\$_\[\s*(\d+)\s*]/ ) {
	        $args[$3] = $2;
	    }
	    elsif( /shift\s*->\s*[a-z0-9_]+\(/ ) {
	        # assuming anonymously used shifted value is $self
		push( @args, '$self' );
	    }
	    elsif( /^\s*\n/ || /^\s*#/ ) {
	        ;
	    }
	    elsif( /}/ ) {
	        $forward = 0;
	    }
	    else {
	        $forward--;
	    }
	}
    }
    if( $proto ) {
        $proto =~ s/\s+//g;
	$proto =~ s/,/, /g;
	@args = split( ", ", $proto );
    }
        
    $name =~ s/\s+$//;
    my $protection = "";
    if( substr( $name, 0, 1 ) eq "_" ) {
        $protection = "protected";
    }
    return( "$protection retval $name( ".join(", ", @args )." )", $name, @args );
}



## @method emit_class( string class, int line, arrayref doc )
# Emit one class definition. If the doc parameter is defined,
# emits the array as a comment just before the class definition,
# otherwise, only the class definition is emitted.
#
# @param class the name of the class
# @param line the current line number
# @param doc (optional) an array with comment lines
sub emit_class {
    my( $self, $class, $line, $doc ) = @_;

    my(@current_isa, @current_include);
    my $file = $self->file_contents();
    while ($_ = $file->[$line++] ) {
	if (/^\s*(?:use base|\@ISA\s*=|\@${class}::ISA\s*=)\s+(.+);/) {
	    @current_isa = eval $1;
	    $file->[$line-1] = "\n";
	} elsif (/^use\s+([\w:]+)/) {
	    my $inc = $1;
	    $inc =~ s/::/\//g;
	    push @current_include, $inc;
	    $file->[$line-1] = "\n";
	} elsif (/^package/) {
	    last;
	}
    }

    $self->print("#include \"$_.pm\"\n") foreach @current_include;
    $self->print("\n");
    
    if( $doc ) {
        $self->start($doc->[0]);
	$self->more( @$doc[1 .. $#$doc] );
	$self->end();
    }
    $self->print("class $class");

    if (@current_isa) {
	$self->print(":",
	    join(", ", map {"public $_"} @current_isa) );
    }
    $self->print(" {\npublic:\n");
}



## @method arrayref file_contents( arrayref contents )
# set/get an array containing the whole input file, each
# line at one array index.
#
# @param contents (optional) file array ref
# @return The file array ref
sub file_contents {
    my( $self, $contents ) = @_;

    $self->{"$id file"} = $contents if( defined $contents );
    return( $self->{"$id file"} );
}



## @method munge_parameters($args)
# Munge the argument list. Because DoxyGen does not seem to handle $, @ and %
# as argument types properly, we replace them with full length strings.
#
# @param args String specifying anything after a directive
# @return Processed string.
sub munge_parameters {
    my ($this, $args) = @_;

    $args =~ s/\$\@/scalar_or_list /g;
    $args =~ s/\@\$/scalar_or_list /g;
    $args =~ s/\$/scalar /g;
    $args =~ s/\@/list /g;
    $args =~ s/\%/hash /g;

#    my ($ret, $remainder) = ($args =~ /^\s*(\S+)(.+)/);
#    if ($ret) {
#        if ($ret eq '$') {
#            $ret = 'scalar';
#        } elsif ($ret eq '@') {
#            $ret = 'list';
#        } elsif ($ret eq '$@') {
#            $ret = 'scalar_or_list';
#        } elsif ($ret eq '@$') {
#            $ret = 'list_or_scalar';
#        }
#
#        $args = "$ret$remainder";
#    }

    return $args;
}


1;
